#ifndef MYTESTSETLST_HPP
#define MYTESTSETLST_HPP

#include "../set/lst/setlst.hpp"

void myTestSetLst(); 
void extendedTestSetLst();

#endif