#ifndef MYTESTVEC_HPP
#define MYTESTVEC_HPP

#include "../set/vec/setvec.hpp"

void mytestvec();
void stresstestvec(); 
void printSetVec100(lasd::SetVec<int> & svec); 

#endif